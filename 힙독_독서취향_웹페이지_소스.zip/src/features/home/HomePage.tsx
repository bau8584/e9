import { useEffect, useRef, useState } from 'react';
import packPage from './philosopher-pack.html?raw';
import { LandingPage } from '../landing/LandingPage';
import { RankingList, useRanking } from '../../components/RankingList';
import { getCharacter, getDm, getMissionCount, getReading } from '../../data';
import { isSeasonComplete } from '../../store/progress';
import { goTo, useSnapshot } from '../../store/store';

const portraitKey = 'hipdok.philosopher.cards.v1';
const catalog: {name:string; theme:string; image:string}[] = JSON.parse(packPage.split('<script id="portrait-data" type="application/json">')[1].split('</script>')[0]);
function validIds(value: unknown): number[] {
  return Array.isArray(value) ? [...new Set(value.filter(id => Number.isInteger(id) && catalog[id]))] : [];
}
function readPortraits() {
  try { return validIds(JSON.parse(localStorage.getItem(portraitKey) || '[]')); } catch { return []; }
}

/** 새 대시보드에 기존 미션·카드 컬렉션·순위를 그대로 연결한다. */
export function HomePage() {
  const packDialog = useRef<HTMLDialogElement>(null);
  const [owned, setOwned] = useState(readPortraits);
  useEffect(() => {
    const changed = (event: Event) => setOwned(validIds((event as CustomEvent).detail));
    const synced = (event: StorageEvent) => { if (!event.key || event.key === portraitKey) setOwned(readPortraits()); };
    window.addEventListener('hipdok:portraits', changed);
    window.addEventListener('storage', synced);
    return () => { window.removeEventListener('hipdok:portraits', changed); window.removeEventListener('storage', synced); };
  }, []);
  const { progress } = useSnapshot();
  const ranking = useRanking(progress.favoriteId, progress.score);
  if (!progress.favoriteId || !ranking) return null;
  const character = getCharacter(progress.favoriteId);
  const reading = getReading(character.id, progress.missionIndex);
  const complete = isSeasonComplete(progress);
  const actions = {dm:'DM에 답하기',reading:'원문 읽기',draw:'카드 뽑기',done:'받은 카드 보기'};
  return <LandingPage>
    <section className="panel hip-return-mission" data-testid={complete?'season-complete':undefined}>
      <h2 className="section-title">{complete?'이번 시즌 완료':`오늘의 읽기 미션 ${progress.missionIndex+1}/${getMissionCount(character.id)}`}</h2>
      <p>{complete?`${character.name}의 이번 시즌 미션을 모두 끝냈어요.`:reading.title}</p>
      <p>내 점수 <strong data-testid="my-score">{progress.score}</strong>점 · 카드 {progress.cards.length}장</p>
      {!complete&&<button className="btn btn-primary" onClick={()=>goTo(progress.stage==='dm'?'dm':'reading')}>{actions[progress.stage]}</button>}
      <button className="hip-return-dm" onClick={()=>goTo('dm')}>{getDm(character.id,progress.missionIndex).preview}</button>
    </section>
    <section className="panel hip-collection">
      <div className="hip-section-head"><div><p className="hip-eyebrow">PORTRAITS OF THOUGHT</p><h2>사유의 초상</h2></div><button className="hip-collection-open" onClick={()=>packDialog.current?.showModal()}>사상가 카드팩 열기</button></div>
      <p>배움·관계·자유 팩에서 사상가를 만나고 초상 카드를 모아 보세요.</p>
      <h3>내가 뽑은 카드 <small>{owned.length} / {catalog.length}</small></h3>
      {owned.length?<ul aria-label="내가 뽑은 카드" className="hip-portrait-grid">{owned.map(id=><li key={id}><img src={catalog[id].image} alt=""/><div><strong>{catalog[id].name}</strong><br/><small>{catalog[id].theme}</small></div></li>)}</ul>:<p>첫 팩을 열면 여기에 나의 첫 초상이 걸려요.</p>}
    </section>
    <dialog ref={packDialog} aria-label="사상가 카드팩" className="hip-pack-dialog"><form method="dialog"><button type="submit" className="btn">닫기</button></form><iframe title="사유의 초상 카드팩" srcDoc={packPage} loading="lazy"/></dialog>
    <RankingList ranking={ranking}/>
  </LandingPage>;
}
