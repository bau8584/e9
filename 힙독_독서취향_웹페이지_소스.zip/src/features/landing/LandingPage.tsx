import { useEffect, useState, type ReactNode } from 'react';
import { ArrowRight, ArrowUpRight, BookMarked, BookOpen, Bookmark, Check, ChevronRight, Compass, Feather, Home, Library, MessageCircle, Search, Sparkles, X } from 'lucide-react';
import hero from '../../assets/philosophy-hero.png';
import xunziSheet from '../../../public/images/xunzi-character-sheet.png';
import { Portrait } from '../../components/Portrait';
import { getCharacter, getReading } from '../../data';
import { goTo, startOnboarding, useSnapshot } from '../../store/store';
import { openDiscovery } from '../discovery/DiscoveryDialog';
import { readResult, readingTypes } from '../discovery/discoveryData';
import './landing.css';

const thoughts = [
  {tag:'나의 기준',title:'남들이 좋다는 삶, 나도 원하는 걸까?',text:'비교하느라 잠깐 잊었던 내 질문을 꺼내봐요.',id:'nietzsche' as const},
  {tag:'작은 실천',title:'내일부터 달라진다는 말, 오늘은 그만.',text:'욕심은 먼저 생겨도, 좋은 행동은 연습할 수 있어요.',id:'xunzi' as const},
];
export function LandingPage({children}: {children?: ReactNode}) {
  const {progress} = useSnapshot();
  const [result,setResult] = useState(readResult);
  const [query,setQuery] = useState('');
  const [active,setActive] = useState<'nietzsche'|'xunzi'>(progress.favoriteId==='xunzi'?'xunzi':'nietzsche');
  const [note,setNote] = useState('');
  const [saved,setSaved] = useState(false);
  const [notice,setNotice] = useState('');
  const guest = progress.screen==='landing';
  const character = getCharacter(active);
  useEffect(() => { const load=()=>setResult(readResult()); window.addEventListener('hipdok:taste-saved',load); return()=>window.removeEventListener('hipdok:taste-saved',load); },[]);
  useEffect(()=>{try{setNote(localStorage.getItem('hipdok:daily-note')??'');}catch{}},[]);
  function meet(id: 'nietzsche'|'xunzi') {if(progress.nickname&&progress.favoriteId===id)goTo('dm');else startOnboarding(id);}
  function saveNote() {try{localStorage.setItem('hipdok:daily-note',note);setSaved(true);setNotice('내 생각을 이 브라우저에 저장했어요.');}catch{setNotice('저장이 막혀 있어요. 글을 복사해 보관해주세요.');}}
  const matches = query.trim() ? readingTypes.filter(t=>`${t.name} ${t.philosopher} ${t.topic}`.includes(query.trim())) : [];
  return <div className={`hip-dashboard${guest?' is-guest':''}`}>
    {guest&&<aside className="hip-sidebar"><a className="hip-logo" href="#hip-home" aria-label="힙독 홈">HIP<span>讀</span></a><p className="hip-slogan">문학에도 최애가 있다</p><div className="hip-sidebar-rule"/>
      <nav aria-label="첫 화면 메뉴"><a className="is-current" href="#hip-home"><Home/>홈</a><button onClick={openDiscovery}><Compass/>발견<span className="hip-new">NEW</span></button><a href="#hip-thinkers"><BookOpen/>철학자</a><button onClick={()=>meet(active)}><MessageCircle/>메시지</button><button onClick={()=>startOnboarding(active)}><Library/>내 방</button></nav>
      <div className="hip-sidebar-rule"/><p className="hip-sidebar-label">오늘의 대화 상대</p>
      {(['nietzsche','xunzi'] as const).map(id=><button key={id} className={`hip-side-person ${active===id?'selected':''}`} onClick={()=>setActive(id)}><Portrait character={getCharacter(id)}/><span>{getCharacter(id).name}</span><span className="hip-online"/></button>)}
      <div className="hip-sidebar-bottom"><span className="hip-reader-mark"><BookMarked/></span><div><strong>아직 모르는 나의 취향</strong><button onClick={openDiscovery}>독서 MBTI 알아보기 <ArrowUpRight size={13}/></button></div></div>
    </aside>}
    <div className="hip-workspace" id="hip-home">
      <header className="hip-topbar"><span className="hip-mobile-logo">HIP<span>讀</span></span><div className="hip-search"><Search size={19}/><input aria-label="철학자와 독서 유형 검색" placeholder="작가, 사상가, 나의 취향을 검색해 보세요" value={query} onChange={e=>setQuery(e.target.value)}/>{query&&<button aria-label="검색어 지우기" onClick={()=>setQuery('')}><X size={16}/></button>}</div><button className="hip-top-link" onClick={openDiscovery}>나의 독서 취향 <ArrowUpRight size={15}/></button><span className="hip-profile" aria-label="독서가 프로필"><Feather size={22}/></span></header>
      {query&&<section className="hip-search-results" aria-label="검색 결과" aria-live="polite"><strong>검색 결과 · {matches.length}개</strong>{matches.length?matches.map(t=><button key={t.code} onClick={()=>{setQuery('');window.dispatchEvent(new CustomEvent('hipdok:discovery',{detail:t.code}));}}>{t.philosopher}<span>{t.name}</span><ChevronRight size={16}/></button>):<p>찾는 취향이 아직 없네요. ‘순자’, ‘장자’, ‘습관’으로 찾아보세요.</p>}</section>}
      <div className="hip-content"><div className="hip-center">
        <header className="hip-welcome"><p className="hip-eyebrow">A LITTLE READING, A NEW PERSPECTIVE</p><h1>오늘도, 최애의 세계로.</h1><p>나를 읽고, 철학자를 만나고, 생각을 이어가요.</p></header>
        <section className={`hip-hero ${active==='xunzi'?'is-xunzi':''}`} aria-label={`${character.name} 소개`} style={{backgroundImage:`url(${hero})`}}><div className="hip-hero-shade"/><div className="hip-hero-copy"><p className="hip-hero-kicker">오늘의 철학 메이트 <span>캐릭터 재해석</span></p><h2>{character.name}</h2><p className="hip-hero-english">{character.englishName}</p><p className="hip-hero-line">{active==='nietzsche'?<>남들이 정한 답 말고,<br/>너만의 기준을 찾는 시간.</>:<>욕심은 먼저 생겨도,<br/>좋은 삶은 배워가는 것.</>}</p><button onClick={()=>meet(active)}><MessageCircle size={20}/>{character.name}와 대화하기 <ArrowRight size={18}/></button></div>{active==='xunzi'&&<div className="hip-xunzi-art" role="img" aria-label="죽간을 읽는 순자의 창작 캐릭터" style={{backgroundImage:`url(${xunziSheet})`}}/>}<div className="hip-hero-switch"><button onClick={()=>setActive('nietzsche')} aria-pressed={active==='nietzsche'}>01 니체</button><span>/</span><button onClick={()=>setActive('xunzi')} aria-pressed={active==='xunzi'}>02 순자</button></div></section>
        <section className="hip-quiz-banner"><span className="hip-quiz-icon"><Sparkles size={27}/></span><div><span className="hip-small-label">READ YOURSELF · 독서 MBTI</span><h2>{result?`나의 취향은 ${result.name}`:'내 책장에 철학자 한 명 들인다면?'}</h2><p>{result?`취향 철학자 ${result.philosopher} · 오늘은 어떤 이야기를 나눌까요?`:'12개의 질문, 16가지 취향. 생각보다 잘 맞는 첫 만남.'}</p></div><button onClick={openDiscovery}>{result?'다시 알아보기':'내 유형 찾기'}<ArrowRight size={17}/></button></section>
        <section className="hip-thinkers" id="hip-thinkers"><div className="hip-section-head"><div><p className="hip-eyebrow">TWO VOICES, YOUR QUESTION</p><h2>지금, 누구와 이야기할까요?</h2></div><span>대화 가능한 철학자 2명</span></div><div className="hip-thinker-grid">{thoughts.map((t,i)=><button key={t.id} className={`hip-thinker-card thinker-${t.id}`} onClick={()=>meet(t.id)}><span className="hip-topic-tag">{t.tag}</span><h3>{t.title}</h3><p>{t.text}</p><div className="hip-thinker-footer"><span className="hip-thinker-monogram">{i===0?'N':'荀'}</span><strong>{getCharacter(t.id).name}와 대화하기</strong><ArrowUpRight size={20}/></div></button>)}</div></section>
        <section className="hip-reading-strip"><span className="hip-reading-book"><BookOpen size={30}/></span><div><span className="hip-small-label">오늘의 한 페이지</span><h3>{progress.favoriteId?getReading(progress.favoriteId,progress.missionIndex).title:'짧게 읽고, 길게 생각하기'}</h3><p>한 편의 글을 읽고 나만의 문장을 수집해요.</p></div><button onClick={()=>guest?startOnboarding(active):goTo('reading')}>읽기 시작 <ChevronRight size={17}/></button></section>
        {children}<footer className="hip-footer"><span>HIP讀 · 문학에도 최애가 있다.</span><span>인물의 대사는 현대적으로 각색한 창작입니다.</span></footer>
      </div><aside className="hip-right">
        <section className="hip-side-card hip-type-card"><p className="hip-small-label"><Compass size={17}/> FIND YOUR PHILOSOPHER</p><h2>책 취향인 줄 알았는데,<br/>내 취향이 나왔다.</h2><div className="hip-book-stack" aria-hidden="true"><div>READ<br/><em>YOUR</em><br/>SELF<span>16 TYPES OF YOU</span></div><span className="hip-book-spine"/></div><p>순자부터 니체, 장자까지.<br/>16명의 철학자로 만나는 나의 독서 취향.</p><button className="hip-outline" onClick={()=>window.dispatchEvent(new CustomEvent('hipdok:discovery',{detail:'types'}))}>16가지 유형 둘러보기 <ArrowRight size={17}/></button></section>
        <section className="hip-side-card hip-note-card"><p className="hip-small-label"><Feather size={16}/> 오늘의 생각 한 줄</p><h2>나는 정말<br/>무엇을 원하고 있을까?</h2><p>누구에게 보여주지 않아도 괜찮아요.</p><label className="hip-sr-only" htmlFor="daily-thought">오늘의 생각</label><textarea id="daily-thought" maxLength={500} placeholder="지금 떠오르는 생각을 남겨보세요." value={note} onChange={e=>{setNote(e.target.value);setSaved(false);}}/><div className="hip-note-actions"><small>{note.length}/500</small><button onClick={saveNote} disabled={!note.trim()}>{saved?<Check size={15}/>:<Bookmark size={15}/>} {saved?'저장했어요':'내 생각 저장'}</button></div><span className="hip-note-status" role="status">{notice}</span></section>
        <section className="hip-side-card hip-record"><span className="hip-small-label"><BookMarked size={17}/> 나의 작은 기록</span><div><p><strong>{progress.cards.length}<small>장</small></strong><span>모은 문장 카드</span></p><p><strong>{progress.score}<small>점</small></strong><span>읽고 쌓은 기록</span></p></div><span className="hip-record-note">{guest?'첫 페이지부터 천천히 쌓아가요.':`${progress.nickname}님의 이야기를 계속해요.`}</span></section>
      </aside></div>
    </div>
  </div>;
}


